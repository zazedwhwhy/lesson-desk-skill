# 生成输入

UTF-8 JSON 顶层有 `project`、`selection`、可选 `pptTemplate`、可选 `assets` 和可选 `reviewNotes`。`assets` 把来源 ID 映射到原文件路径，例如 `{"paper":"inputs/paper.pdf","key":"inputs/key.docx"}`。`reviewNotes` 是给教师看的待核对条目数组，写清题号、缺失项和可采取的核对动作。路径以 JSON 所在目录为基准。按授课顺序排列篇目、材料组和题目。未知字段会报错并带出字段路径。旧版 `manifest.json` 出 PPT 时需补 `selection` 和已有答案的来源。已经生成的课件包仍可导入。

所有学科的 `project` 都需要 `title`、`subject`、`sources`。来源用 `{ "id":"paper", "name":"试卷.pdf", "role":"paper", "kind":"pdf", "blocks":[{"id":"b1","text":"原文逐字摘录","page":2}] }`。`role` 可取 `paper/answer/listening`，`kind` 可取 `pdf/docx/text`。至少提供一个 `paper`。PDF 和 DOCX 在 `assets` 中关联该 ID 对应的原文件；粘贴文本使用 `text`，直接保存原文块。页码从 1 起，未知时省略。尽量把题干和参考答案也放在各自来源的文字块里。各层 ID 用唯一、稳定的英文标识，引用使用实际存在的 ID。

### 授课 PPT 样式

在清单顶层写 `"pptTemplate":"paper"`、`"blue"` 或 `"forest"`。省略时使用纸面教案。老师指定样式时，同一次导出的题目、原图和答案都沿用该样式。

| 值 | 工作台名称 | 上课怎么翻 |
| --- | --- | --- |
| `paper` | 纸面教案 | 先展示原题，再用纸色底和朱色批注并读答案、解析与证据。 |
| `blue` | 包豪斯板书 | 蓝色左栏保留篇目和题号，右侧留给原文、图或讲解。 |
| `forest` | 影院暗场 | 深色底突出当前要点。讲评中的答案、解析和原文依据可逐页揭示。 |

三种模板使用与桌面放映相同的分页和题面顺序，正文可在 PowerPoint 中编辑。用新版工作台打开课件包时会采用清单中指定的模板；教师可在编排页切换。同一份材料要出三版时，复用同一个 `project` 和 `selection`，分别指定三种 `pptTemplate`，各自输出到新目录。

### 交付范围

`selection` 每项指定一个模块和材料 ID。正常生成 PPT 时必填。只做整理、校对或保存待核对草稿时，可使用 `--bundle-only` 并省略此字段。所选内容缺失、未完成或已排除时停止构建。需要部分交付时，取得老师同意后移除对应选项，疑点仍保留在课件包和核对清单。

| 学科 | 逐题选项示例 | 篇目或材料组选项示例 |
| --- | --- | --- |
| 英语 | `{"passageId":"reading1","questionId":"q21","module":"analysis"}` | `{"passageId":"reading1","module":"lexicon"}` |
| 语文 | `{"groupId":"g1","questionId":"q7","module":"practice"}` | `{"groupId":"g1","module":"structure"}` |
| 化学 | `{"questionId":"q4","module":"experiment"}` | 题面和原图用 `{"questionId":"q4","module":"source"}` |

英语逐题讲评、考点演练和阅读、听力、七选五、完形专项需给题目 ID。写作、续写专项用篇目 ID。英语和语文的原文用 `source`；各学科模块名与下面的字段一致。课件包可保留其他已生成或待核对的材料和讲义，PPT 根据 `selection` 出片。

### 答案来源与待核对试解

- 填写原题 `answer` 时，同时给出 `answerEvidence: {sourceId, blockId, quote}`。引用 `role: "answer"` 来源中的完整答案行或表，原样保留题号和答案。支持如 `21. A`、`第 7 题：雨后安静。`、`21–24 ABCD`。既有试卷又有同卷答案时，可分别登记来源角色。难以把完整答案与题号对应时列为待核对。
- 老师明确要求试解时，填 `trialAnswer`，将 `answer` 留空，省略答案来源。英语另外用 `analysis` 存放同一试解和解题依据。保存待核对课件包；其他可用内容可照常按所选范围出片。
- 老师明确确认答案及本次材料、讲义范围后，把确认的答案填入 `answer`，设 `answerOrigin: "teacher"`，去掉 `trialAnswer`，使用 `--teacher-reviewed`。重新核对解析是否与老师确认的答案一致。

## 英语

在 `project` 中添加 `passages` 和 `questions`。以下是最小示例，实际回答要用老师提交的材料。

```json
{
  "selection": [
    {"passageId":"reading1","module":"source"},
    {"passageId":"reading1","questionId":"q21","module":"analysis"}
  ],
  "project": {
    "title": "阅读讲评",
    "subject": "english",
    "sources": [
      {"id":"paper","name":"原卷","role":"paper","kind":"text","blocks":[{"id":"p1","text":"The team started early to avoid the heat."},{"id":"stem21","text":"21. Why did the team start early? A. To avoid the heat. B. To catch a bus."}]},
      {"id":"key","name":"参考答案","role":"answer","kind":"text","blocks":[{"id":"a21","text":"21. A"}]}
    ],
    "passages": [{"id":"reading1","title":"Reading A","type":"reading","paragraphs":[{"id":"p1","text":"The team started early to avoid the heat."}]}],
    "questions": [{"id":"q21","number":"21","sourceId":"paper","passageId":"reading1","type":"reading","stem":"Why did the team start early?","options":["A. To avoid the heat.","B. To catch a bus."],"answer":"A","answerEvidence":{"sourceId":"key","blockId":"a21","quote":"21. A"},"analysis":{"answer":"A","text":"不定式 to avoid the heat 直接交代出发目的。B 项的公交车在文中没有依据。","evidence":[{"blockId":"p1","quote":"to avoid the heat"}]}}]
  }
}
```

`type` 可取 `reading/seven/cloze/grammar/listening/writing/continuation`。`answer` 是参考答案，`analysis.answer` 是解析所得答案。选择题用同一答案编号格式，实质冲突时写真实分歧，构建器会排除该题。题面缺失、模糊或不能和答案绑定时可标 `excluded:true`，略去无法证实的解析和引用。完全读不出题干的条目只记在 `reviewNotes`，注明原卷页码。英语题图由原件保留，现有英语 PPT 导出不支持单题配图。依赖原图作答的题应留待核对。一篇的共用选项池填 `pool`，篇目译文填 `translation`。

词汇手账用篇目的 [`lexicon` 数组](lexicon.md)。只做篇目级内容时设 `questions: []`，原文来源仍保留。要加句法拆解、篇章脉络或表达迁移，给篇目加 `teaching: {modules, data}`，`modules` 使用 `sentences/structure/imitation` 中实选的值。`data` 的固定形状如下，未选的数组留空，未选篇章时 `structure` 的字符串留空并设 `outline:[]`。同一篇可同时填写 `lexicon` 和 `teaching`。

| 字段 | 每项字段 |
| --- | --- |
| `sentences` | `quote, translation, trunk, clauses, examTip`，可加 `parts` 数组，每项 `{text,role,explanation}` |
| `structure` | 对象 `genre, theme, outline, logic, examFocus`，`outline` 每项 `{paragraph,endParagraph,role,summary}`，段号从 1 起 |
| `lexicon` | 新课件填 `[]`，词条放在篇目级 `lexicon`。旧清单用 `modules:["lexicon"]` 和 `data.lexicon`，条目字段为 `term, meaning, sourceQuote, collocations, contrast, memory, quiz, answer`，可加 `sourceForm, partOfSpeech, usageNote, memoryExample, exampleTranslation`。同一篇只用一种写法。 |
| `imitation` | `quote, pattern, why, example, task, reference, checklist`，`checklist` 是字符串数组 |
| `transfer` | 留空。独立考点演练填到题目的 `analysis.practice` |

`questions[].practice` 为 `{kind,skill,sourceTopic,newTopic,material,stem,options,answer,analysis,point}`，可单独生成。旧清单也可用 `analysis.practice`，每题选一种写法。英文新材料要自足，题型与原题一致。专项讲评的 `passages[].special`、校对和修正的输入见 [三科备课功能](workflows.md)。

## 语文

`project.subject` 为 `chinese`。`project.groups` 每项包含 `id, section, title, kind, materials, questions, versions`。`kind` 可取 `information/literature/classical/poetry/recitation/language/writing`。

- 材料为 `{id,title,text,sourceId,blockIds}`，有原图时加 `imageFile`（PNG 或 JPEG）。`sourceId` 和 `blockIds` 对应 `sources`。应重新核对的整组可写 `sourceNeedsReview:true`。
- 题目为 `{id,number,stem,format,materialIds,options,answer}`，`format` 可取 `choice/short/translation/segmentation/recitation/revision/expression/essay`。冲突或未核对的题加 `excluded:true` 和清单说明。保留原选项字面。
- 讲义为 `{module,questionId,result}`。`module` 可取 `analysis/structure/language/translation/writing/practice`，逐题讲评和演练用 `questionId` 关联原题，组级模块省略。要放映某道题的演练，同时提供其可用的逐题讲评。`result` 为 `{status,notices,blocks}`，`status` 可取 `ok/needs_review/insufficient_material`，`notices` 是字符串数组，`blocks` 每项为 `{label,text,evidence:[{materialId,quote}]}`。`quote` 是该材料的原文字面，非引用块填 `evidence:[]`。

## 化学

`project.subject` 为 `chemistry`。`project.questions` 每项包含 `id,number,stem,options,answer,sourceId,pages,images,versions`。`pages` 是原文件页码数组；`stage` 可取 `junior/senior`，`kind` 可取 `choice/principle/calculation/experiment/process/organic`。题面或题图存疑时加 `excluded:true`。

- `images` 每项为 `{id,name,file,sourceId,page,description}`。`file` 指向从原卷裁的 PNG 或 JPEG，保留坐标、箭头和图注。题目有配图时可设 `imageMode:"vision"`；使用 `description` 模式时每张图补实质性的 `description`。
- `versions` 每项为 `{module,result}`。`module` 可取 `analysis/knowledge/method/experiment/practice`。`result` 为 `{status,notices,blocks}`，状态与语文相同。每个内容块是 `{label,text}`。考点演练使用三个内容块，标签依次为 `题目`、`答案`、`解析与迁移`。化学方程、上下标可用 `$\ce{2H2 + O2 -> 2H2O}$` 或 LaTeX，写进 JSON 文件时转义反斜杠。

## 打包约定

原件原字节写入课件包。`project.json` 由脚本生成。待核对 PPT 按 `selection` 出片，课件包保留需补充的题和待确认讲义。只需要课件包和核对清单时用 `--bundle-only`。PPT 使用工作台内置纸面教案版式。
